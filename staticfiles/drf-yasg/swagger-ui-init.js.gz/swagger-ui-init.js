"use strict";
var currentPath = window.location.protocol + "
var defaultSpecUrl = currentPath + '?format=openapi';
function slugify(text) {
return text.toString().toLowerCase()
.replace(/\s+/g, '-')           
.replace(/[^\w\-]+/g, '')       
.replace(/--+/g, '-')           
.replace(/^-+/, '')             
.replace(/-+$/, '');            
}
var KEY_AUTH = slugify(window.location.pathname) + "-drf-yasg-auth";
var savedAuth = Immutable.fromJS({});
var swaggerUiConfig = {
url: defaultSpecUrl,
dom_id: '#swagger-ui',
displayRequestDuration: true,
presets: [
SwaggerUIBundle.presets.apis,
SwaggerUIStandalonePreset
],
plugins: [
SwaggerUIBundle.plugins.DownloadUrl
],
layout: "StandaloneLayout",
filter: true,
requestInterceptor: function (request) {
var headers = request.headers || {};
var csrftoken = document.querySelector("[name=csrfmiddlewaretoken]");
if (csrftoken) {
headers["X-CSRFToken"] = csrftoken.value;
}
return request;
}
};
function patchSwaggerUi() {
if (document.querySelector('.auth-wrapper #django-session-auth')) {
return;
}
var authWrapper = document.querySelector('.auth-wrapper');
var authorizeButton = document.querySelector('.auth-wrapper .authorize');
var djangoSessionAuth = document.querySelector('#django-session-auth');
if (!djangoSessionAuth) {
console.log("WARNING: session auth disabled");
return;
}
djangoSessionAuth = djangoSessionAuth.cloneNode(true);
authWrapper.insertBefore(djangoSessionAuth, authorizeButton);
djangoSessionAuth.classList.remove("hidden");
}
function initSwaggerUi() {
if (window.ui) {
console.log("WARNING: skipping initSwaggerUi() because window.ui is already defined");
return;
}
if (document.querySelector('.auth-wrapper .authorize')) {
patchSwaggerUi();
} else {
insertionQ('.auth-wrapper .authorize').every(patchSwaggerUi);
}
var swaggerSettings = JSON.parse(document.getElementById('swagger-settings').innerHTML);
var oauth2RedirectUrl = document.getElementById('oauth2-redirect-url');
if (oauth2RedirectUrl) {
if (!('oauth2RedirectUrl' in swaggerSettings)) {
if (oauth2RedirectUrl) {
swaggerSettings['oauth2RedirectUrl'] = oauth2RedirectUrl.href;
}
}
oauth2RedirectUrl.parentNode.removeChild(oauth2RedirectUrl);
}
console.log('swaggerSettings', swaggerSettings);
var oauth2Config = JSON.parse(document.getElementById('oauth2-config').innerHTML);
console.log('oauth2Config', oauth2Config);
initSwaggerUiConfig(swaggerSettings, oauth2Config);
window.ui = SwaggerUIBundle(swaggerUiConfig);
window.ui.initOAuth(oauth2Config);
}
function initSwaggerUiConfig(swaggerSettings, oauth2Settings) {
var persistAuth = swaggerSettings.persistAuth;
var refetchWithAuth = swaggerSettings.refetchWithAuth;
var refetchOnLogout = swaggerSettings.refetchOnLogout;
var fetchSchemaWithQuery = swaggerSettings.fetchSchemaWithQuery;
delete swaggerSettings['persistAuth'];
delete swaggerSettings['refetchWithAuth'];
delete swaggerSettings['refetchOnLogout'];
delete swaggerSettings['fetchSchemaWithQuery'];
for (var p in swaggerSettings) {
if (swaggerSettings.hasOwnProperty(p)) {
swaggerUiConfig[p] = swaggerSettings[p];
}
}
var specURL = swaggerUiConfig.url;
if (fetchSchemaWithQuery) {
var query = new URLSearchParams(window.location.search || '').entries();
for (var it = query.next(); !it.done; it = query.next()) {
specURL = setQueryParam(specURL, it.value[0], it.value[1]);
}
}
if (persistAuth) {
try {
savedAuth = Immutable.fromJS(JSON.parse(localStorage.getItem(KEY_AUTH)) || {});
} catch (e) {
localStorage.removeItem(KEY_AUTH);
}
}
if (refetchWithAuth) {
specURL = applyAuth(savedAuth, specURL) || specURL;
}
swaggerUiConfig.url = specURL;
if (persistAuth || refetchWithAuth) {
var hookedAuth = false;
var oldOnComplete = swaggerUiConfig.onComplete;
swaggerUiConfig.onComplete = function () {
if (persistAuth) {
preauthorizeAll(savedAuth, window.ui);
}
if (!hookedAuth) {
hookAuthActions(window.ui, persistAuth, refetchWithAuth, refetchOnLogout);
hookedAuth = true;
}
if (oldOnComplete) {
oldOnComplete();
}
};
var specRequestsInFlight = {};
var oldRequestInterceptor = swaggerUiConfig.requestInterceptor;
swaggerUiConfig.requestInterceptor = function (request) {
var headers = request.headers || {};
if (request.loadSpec) {
var newUrl = request.url;
if (refetchWithAuth) {
newUrl = applyAuth(savedAuth, newUrl, headers) || newUrl;
}
if (newUrl !== request.url) {
request.url = newUrl;
if (window.ui) {
window.ui.specActions.updateUrl(request.url);
} else {
setTimeout(function () {
window.ui.specActions.updateUrl(request.url);
});
}
var absUrl = new URL(request.url, currentPath);
specRequestsInFlight[absUrl.href] = request.url;
}
}
if (oldRequestInterceptor) {
request = oldRequestInterceptor(request);
}
return request;
};
var oldResponseInterceptor = swaggerUiConfig.responseInterceptor;
swaggerUiConfig.responseInterceptor = function (response) {
var absUrl = new URL(response.url, currentPath);
if (absUrl.href in specRequestsInFlight) {
var setToUrl = specRequestsInFlight[absUrl.href];
delete specRequestsInFlight[absUrl.href];
if (response.ok) {
setTimeout(function () {
var currentUrl = new URL(window.ui.specSelectors.url(), currentPath);
if (currentUrl.href !== absUrl.href) {
window.ui.specActions.updateUrl(setToUrl);
}
});
}
}
if (oldResponseInterceptor) {
response = oldResponseInterceptor(response);
}
return response;
}
}
}
function _usp(url, fn) {
url = url.split('?');
var usp = new URLSearchParams(url[1] || '');
fn(usp);
url[1] = usp.toString();
return url[1] ? url.join('?') : url[0];
}
function setQueryParam(url, key, value) {
return _usp(url, function (usp) {
usp.set(key, value);
});
}
function removeQueryParam(url, key) {
return _usp(url, function (usp) {
usp.delete(key);
})
}
function preauthorizeAll(authorization, sui) {
authorization.valueSeq().forEach(function (authScheme) {
var schemeName = authScheme.get("name"), schemeType = authScheme.getIn(["schema", "type"]);
if (schemeType === "basic" && schemeName) {
var username = authScheme.getIn(["value", "username"]);
var password = authScheme.getIn(["value", "password"]);
if (username && password) {
sui.preauthorizeBasic(schemeName, username, password);
}
} else if (schemeType === "apiKey" && schemeName) {
var key = authScheme.get("value");
if (key) {
sui.preauthorizeApiKey(schemeName, key);
}
} else {
}
});
}
function applyAuth(authorization, requestUrl, requestHeaders) {
authorization.valueSeq().forEach(function (authScheme) {
requestHeaders = requestHeaders || {};
var schemeName = authScheme.get("name"), schemeType = authScheme.getIn(["schema", "type"]);
if (schemeType === "basic" && schemeName) {
var username = authScheme.getIn(["value", "username"]);
var password = authScheme.getIn(["value", "password"]);
if (username && password) {
requestHeaders["Authorization"] = "Basic " + btoa(username + ":" + password);
}
} else if (schemeType === "apiKey" && schemeName) {
var _in = authScheme.getIn(["schema", "in"]), paramName = authScheme.getIn(["schema", "name"]);
var key = authScheme.get("value");
if (key && paramName) {
if (_in === "header") {
requestHeaders[paramName] = key;
}
if (_in === "query") {
if (requestUrl) {
requestUrl = setQueryParam(requestUrl, paramName, key);
} else {
console.warn("WARNING: cannot apply apiKey query parameter via interceptor");
}
}
}
} else {
}
});
return requestUrl;
}
function deauthUrl(authorization, requestUrl) {
authorization.valueSeq().forEach(function (authScheme) {
var schemeType = authScheme.getIn(["schema", "type"]);
if (schemeType === "apiKey") {
var _in = authScheme.getIn(["schema", "in"]), paramName = authScheme.getIn(["schema", "name"]);
if (_in === "query" && requestUrl && paramName) {
requestUrl = removeQueryParam(requestUrl, paramName);
}
} else {
}
});
return requestUrl;
}
function hookAuthActions(sui, persistAuth, refetchWithAuth, refetchOnLogout) {
if (!persistAuth && !refetchWithAuth) {
return;
}
var originalAuthorize = sui.authActions.authorize;
sui.authActions.authorize = function (authorization) {
originalAuthorize(authorization);
var newAuths = Immutable.fromJS(authorization);
savedAuth = savedAuth.merge(newAuths);
if (refetchWithAuth) {
var url = sui.specSelectors.url();
url = applyAuth(savedAuth, url) || url;
sui.specActions.updateUrl(url);
sui.specActions.download();
sui.authActions.showDefinitions(); 
}
if (persistAuth) {
localStorage.setItem(KEY_AUTH, JSON.stringify(savedAuth.toJSON()));
}
};
var originalLogout = sui.authActions.logout;
sui.authActions.logout = function (authorization) {
var loggedOut = savedAuth.filter(function (val, key) {
return authorization.indexOf(key) !== -1;
}).mapEntries(function (entry) {
return [entry[0], entry[1].set("value", null)]
});
savedAuth = savedAuth.filter(function (val, key) {
return authorization.indexOf(key) === -1;
});
if (refetchWithAuth) {
var url = sui.specSelectors.url();
url = deauthUrl(loggedOut, url) || url;
sui.specActions.updateUrl(url);
sui.specActions.download(url);
sui.authActions.showDefinitions(); 
}
if (persistAuth) {
localStorage.setItem(KEY_AUTH, JSON.stringify(savedAuth.toJSON()));
}
originalLogout(authorization);
};
}
window.addEventListener('load', initSwaggerUi);